﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Car
    {
        private string brand;
        private string model;
        private int year;

        public Car()
        {
            brand = "Unknown";
            model = "Unknown";
            year = 0;
        }

        public Car(string brand, string model, int year)
        {
            this.brand = brand;
            this.model = model;
            this.year = year;
        }

        public Car(Car c)
        {
            this.brand = c.brand;
            this.model = c.model;
            this.year = c.year;
        }

        public string Brand { get { return brand; } set { brand = value; } }
        public string Model { get { return model; } set { model = value; } }
        public int Year { get { return year; } set { year = value; } }

        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Car: {brand} {model}, Year: {year}");
        }

        public void DisplayInfo(string owner)
        {
            Console.WriteLine($"Owner: {owner}, Car: {brand} {model}, Year: {year}");
        }
    }
}
