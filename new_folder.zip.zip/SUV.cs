﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class SUV : Car
    {
        public int GroundClearance;

        public SUV(string brand, string model, int year, int groundClearance) : base(brand, model, year)
        {
            this.GroundClearance = groundClearance;
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Ground Clearance: {GroundClearance} inches");
        }
    }
}
