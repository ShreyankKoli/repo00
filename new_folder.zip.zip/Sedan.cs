﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Sedan : Car
    {
        public int TrunkSize;

        //base is used to call the constructor of the base class (Car) from the derived class (Sedan).

        public Sedan(string brand, string model, int year, int trunkSize) : base(brand, model, year)
        {
            this.TrunkSize = trunkSize;
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Trunk Size: {TrunkSize} cubic feet");
        }
    }
}
