﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class LuxurySedan : Sedan
    {
        public bool HasSunroof;

        public LuxurySedan(string brand, string model, int year, int trunkSize, bool hasSunroof) : base(brand, model, year, trunkSize)
        {
            this.HasSunroof = hasSunroof;
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Sunroof: {(HasSunroof ? "Yes" : "No")}");
        }
    }
}
