﻿using ConsoleApp1;
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter Car Brand: ");
        string brand = Console.ReadLine();

        Console.Write("Enter Car Model: ");
        string model = Console.ReadLine();

        Console.Write("Enter Year of Manufacturing: ");
        int year = int.Parse(Console.ReadLine());

        Console.Write("Enter Trunk Size for Sedan (or 0 for none): ");
        int trunkSize = int.Parse(Console.ReadLine());

        Console.Write("Enter Ground Clearance for SUV (or 0 for none): ");
        int groundClearance = int.Parse(Console.ReadLine());

        Console.Write("Does it have a sunroof? (yes/no): ");
        bool hasSunroof = Console.ReadLine().ToLower() == "yes";

        Console.WriteLine("\nCar Details:\n");

        Car myCar = new Car(brand, model, year);
        myCar.DisplayInfo();

        if (trunkSize > 0 && groundClearance == 0)
        {
            Sedan mySedan = new Sedan(brand, model, year, trunkSize);
            mySedan.DisplayInfo();
        }
        else if (trunkSize > 0 && hasSunroof)
        {
            LuxurySedan myLuxury = new LuxurySedan(brand, model, year, trunkSize, hasSunroof);
            myLuxury.DisplayInfo();
        }
        else if (groundClearance > 0)
        {
            SUV mySUV = new SUV(brand, model, year, groundClearance);
            mySUV.DisplayInfo();
        }
    }
}
